const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

// Tambah buku baru (CREATE)
router.post('/', async (req, res) => {
    const { title, author, borrower } = req.body;
    const newBook = new Book({ title, author, borrower });
    await newBook.save();
    res.json(newBook);
});

// Tampilkan semua buku (READ)
router.get('/', async (req, res) => {
    const books = await Book.find();
    res.json(books);
});

// Edit buku (UPDATE)
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { title, author, borrower } = req.body;
    const updatedBook = await Book.findByIdAndUpdate(id, { title, author, borrower }, { new: true });
    res.json(updatedBook);
});

// Hapus buku (DELETE)
router.delete('/:id', async (req, res) => {
    const { id } = req.params;
    await Book.findByIdAndDelete(id);
    res.json({ message: 'Buku dihapus' });
});

module.exports = router;
