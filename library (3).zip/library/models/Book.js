const mongoose = require('mongoose');

// Schema Buku
const BookSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: true
    },
    borrower: {
        type: String,
        required: true
    },
    borrowedDate: {
        type: Date,
        default: Date.now
    }
});

// Tentukan nama collection secara eksplisit
module.exports = mongoose.model('Book', BookSchema, 'library');
