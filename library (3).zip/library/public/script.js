document.getElementById('bookForm').addEventListener('submit', addOrUpdateBook);
document.getElementById('downloadPdfBtn').addEventListener('click', downloadPdf); // Tambahkan event listener untuk download PDF

let editMode = false;
let editBookId = null;

async function addOrUpdateBook(e) {
    e.preventDefault();

    const title = document.getElementById('title').value;
    const author = document.getElementById('author').value;
    const borrower = document.getElementById('borrower').value;

    if (editMode) {
        // Mode Edit
        await fetch(`/books/${editBookId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, author, borrower })
        });
        editMode = false;
        editBookId = null;
    } else {
        // Mode Tambah
        await fetch('/books', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, author, borrower })
        });
    }

    document.getElementById('bookForm').reset(); // Reset form setelah submit
    displayBooks(); // Tampilkan daftar buku terbaru
}

async function displayBooks() {
    const res = await fetch('/books');
    const books = await res.json();

    const booksList = document.getElementById('booksList');
    booksList.innerHTML = '';

    books.forEach(book => {
        const bookCard = document.createElement('div');
        bookCard.classList.add('book-card');
        bookCard.innerHTML = `
            <h3>${book.title}</h3>
            <p>Author: ${book.author}</p>
            <p>Borrower: ${book.borrower}</p>
            <p>Date: ${new Date(book.borrowedDate).toLocaleDateString()}</p>
            <button onclick="editBook('${book._id}', '${book.title}', '${book.author}', '${book.borrower}')">Edit</button>
            <button onclick="deleteBook('${book._id}')">Hapus</button>
        `;
        booksList.appendChild(bookCard);
    });
}

function editBook(id, title, author, borrower) {
    document.getElementById('title').value = title;
    document.getElementById('author').value = author;
    document.getElementById('borrower').value = borrower;

    editMode = true;
    editBookId = id;
}


// Fungsi untuk menghapus buku
async function deleteBook(bookId) {
    if (confirm('Apakah Anda yakin ingin menghapus buku ini?')) {
        try {
            // Kirim permintaan DELETE ke server untuk menghapus buku
            await fetch(`/books/${bookId}`, { method: 'DELETE' });
            displayBooks(); // Refresh daftar buku setelah penghapusan
        } catch (error) {
            console.error("Gagal menghapus buku:", error);
        }
    }
}
// Fungsi untuk download PDF
async function downloadPdf() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    const res = await fetch('/books');
    const books = await res.json();

    doc.setFontSize(16);
    doc.text('Borrowed Books List', 10, 10);

    let yOffset = 20; // Y-offset for writing book data in PDF

    books.forEach((book, index) => {
        doc.setFontSize(12);
        doc.text(`${index + 1}. Title: ${book.title}`, 10, yOffset);
        doc.text(`   Author: ${book.author}`, 10, yOffset + 10);
        doc.text(`   Borrower: ${book.borrower}`, 10, yOffset + 20);
        doc.text(`   Date: ${new Date(book.borrowedDate).toLocaleDateString()}`, 10, yOffset + 30);
        yOffset += 40; // Move down for the next book
    });

    doc.save('borrowed_books.pdf');
}

document.addEventListener('DOMContentLoaded', displayBooks);